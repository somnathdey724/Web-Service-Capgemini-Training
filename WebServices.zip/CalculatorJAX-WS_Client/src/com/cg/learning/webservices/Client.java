package com.cg.learning.webservices;
import java.net.URL;
import java.util.Scanner;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
public class Client {

	public static void main(String[] args) throws Exception {
		
		URL url= new URL("http://localhost:9876/cs?wsdl");

		//Qualified name of the service
		//1st arg is the service URI
		//2nd is the service name published in WSDL		
		QName qname = new QName("http://webservices.learning.cg.com/", "CalculatorService");

		//Create a factory for the service
		Service service = Service.create(url, qname);

		//Extract the endpointInterface, the service "port".
		CalculatorServer endPointIntf=service.getPort(CalculatorServer.class);

		Scanner scanner= new Scanner(System.in);
		System.out.println("Enter first number for calculator operation");
		int number1=scanner.nextInt();
		System.out.println("Enter second number for calculator operation");
		int number2=scanner.nextInt();
		System.out.println("Addition::\t"+endPointIntf.addition(number1, number2));
		System.out.println("Subtraction::\t"+endPointIntf.substraction(number1, number2));
		System.out.println("Multiplication::\t"+endPointIntf.multiplication(number1, number2));
		System.out.println("Division::\t"+endPointIntf.division(number1, number2));
		System.out.println("Modulus::\t"+endPointIntf.modulus(number1, number2));
	}
}
